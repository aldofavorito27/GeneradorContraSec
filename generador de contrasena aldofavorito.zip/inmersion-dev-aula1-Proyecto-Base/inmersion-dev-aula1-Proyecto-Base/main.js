let cantidad = document.getElementById('cantidad');
let boton = document.getElementById('generar');
let contrasena = document.getElementById('contrasena')


const cadenaCaracteres1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const cadenaCaracteres2 = 'abcdefghijklmnopqrstuvwxyz';
const cadenaCaracteres3 = '0123456789';
const cadenaCaracteres4 = '!@#$%^&*()?¿¡-_';


function generar(){

    let numeroDigitado = parseInt(cantidad.value);


    //AQUI escogemos el tamano minimo de la contrasena 
    if(numeroDigitado<8){
        alert("La cantidad de caracteres debe ser Mayor o igual a 8");
        return;
    }

    let Password = "";
    //AQUI dividimos el tamano de la contrasena en partes iguales dependiendo  
    for(let i=0; i < numeroDigitado/4; i++){

        let caracteresAleatorio1 = cadenaCaracteres1[Math.floor(Math.random()* cadenaCaracteres1.length)];
        console.log(caracteresAleatorio1);

        let caracteresAleatorio2 = cadenaCaracteres2[Math.floor(Math.random()* cadenaCaracteres2.length)];
        console.log(caracteresAleatorio2);

        let caracteresAleatorio3 = cadenaCaracteres3[Math.floor(Math.random()* cadenaCaracteres3.length)];
        console.log(caracteresAleatorio3);

        let caracteresAleatorio4 = cadenaCaracteres4[Math.floor(Math.random()* cadenaCaracteres4.length)];
        console.log(caracteresAleatorio4);

        Password+= caracteresAleatorio1+caracteresAleatorio2+caracteresAleatorio3+caracteresAleatorio4
    }


    console.log('contrasena guardada :' + Password);
    contrasena.value= Password

    }



